from __future__ import annotations

from typing import Generic, TypeVar

from pydantic import BaseModel
from pydantic.generics import GenericModel

T = TypeVar("T")


class SuccessResponse(GenericModel, Generic[T]):
    success: bool = True
    message: str = "Success"
    data: T


class ErrorResponse(BaseModel):
    success: bool = False
    message: str = "Error"
    detail: str